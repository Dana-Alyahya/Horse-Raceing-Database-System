package horseracing.services;

import horseracing.dao.HorseDAO;
import horseracing.dao.TrackDAO;
import horseracing.dao.TrainerDAO;

// GuestService.java
public class GuestService {
    private HorseDAO horseDAO = new HorseDAO();
    private TrainerDAO trainerDAO = new TrainerDAO();
    private TrackDAO trackDAO = new TrackDAO();

    public java.util.List<String> browseHorsesByOwner(String ownerLname) throws Exception {
        return horseDAO.getHorsesByOwner(ownerLname);
    }

    public java.util.List<String> listWinningTrainers() throws Exception {
        return trainerDAO.getWinningTrainers();
    }

    public java.util.List<String> listTrainerWinnings() throws Exception {
        return trainerDAO.getTrainerWinnings();
    }

    public java.util.List<String> listTracksWithRaceCounts() throws Exception {
        return trackDAO.getTrackStats();
    }
}

