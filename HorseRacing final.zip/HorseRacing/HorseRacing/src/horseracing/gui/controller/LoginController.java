package horseracing.gui.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private void handleAdminLogin(ActionEvent event) throws IOException {
        loadScene("AdminView.fxml", event, "Admin Menu");
    }

    @FXML
    private void handleGuestLogin(ActionEvent event) throws IOException {
        loadScene("GuestView.fxml", event, "Guest Menu");
    }

    private void loadScene(String fxmlPath, ActionEvent event, String title) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/" + fxmlPath));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle(title);
        stage.setScene(new Scene(root));
        stage.show();
    }
}

