package horseracing.gui.controller;

import horseracing.services.GuestService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class ListWinningTrainersController {

    @FXML
    private ListView<String> trainerListView;

    private GuestService guestService = new GuestService();

    @FXML
    public void initialize() {
        handleListWinningTrainers(null); // Load data on initialization
    }

    @FXML
    private void handleListWinningTrainers(ActionEvent event) {
        try {
            List<String> trainers = guestService.listWinningTrainers();
            ObservableList<String> observableTrainers = FXCollections.observableArrayList(trainers);
            trainerListView.setItems(observableTrainers);

            if (trainers.isEmpty()) {
                showAlert(Alert.AlertType.INFORMATION, "No Results", "No winning trainers found.");
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to list winning trainers: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBackToGuest(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/GuestView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Guest Menu");
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

