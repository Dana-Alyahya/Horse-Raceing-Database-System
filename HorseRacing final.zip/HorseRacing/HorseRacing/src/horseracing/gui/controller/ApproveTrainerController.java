package horseracing.gui.controller;

import horseracing.services.AdminService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class ApproveTrainerController {

    @FXML
    private TextField trainerIdField;
    @FXML
    private TextField stableIdField;

    private AdminService adminService = new AdminService();

    @FXML
    private void handleApproveTrainer(ActionEvent event) {
        if (trainerIdField.getText().trim().isEmpty() || stableIdField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Both Trainer ID and Stable ID must be filled out.");
            return;
        }
        try {
            String trainerId = trainerIdField.getText();
            String stableId = stableIdField.getText();
            adminService.approveTrainer(trainerId, stableId);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Trainer approved successfully!");
            trainerIdField.clear();
            stableIdField.clear();
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to approve trainer: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/AdminView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Admin Menu");
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

