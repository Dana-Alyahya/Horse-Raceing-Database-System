package horseracing.gui.controller;

import horseracing.model.Race;
import horseracing.model.RaceResults;
import horseracing.services.AdminService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import java.util.InputMismatchException;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Date;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class AddRaceController {

    @FXML
    private TextField raceIdField;
    @FXML
    private TextField raceNameField;
    @FXML
    private TextField trackNameField;
    @FXML
    private TextField raceDateField;
    @FXML
    private TextField raceTimeField;

    @FXML
    private TextField horseIdField;
    @FXML
    private TextField resultField;
    @FXML
    private TextField prizeField;

    private AdminService adminService = new AdminService();

    @FXML
    private void handleAddRace(ActionEvent event) {
        if (raceIdField.getText().trim().isEmpty() ||
            raceNameField.getText().trim().isEmpty() ||
            trackNameField.getText().trim().isEmpty() ||
            raceDateField.getText().trim().isEmpty() ||
            raceTimeField.getText().trim().isEmpty() ||
            horseIdField.getText().trim().isEmpty() ||
            resultField.getText().trim().isEmpty() ||
            prizeField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "All fields must be filled out.");
            return;
        }
        try {
            String raceId = raceIdField.getText();
            String raceName = raceNameField.getText();
            String trackName = trackNameField.getText();
            Date raceDate = Date.valueOf(raceDateField.getText());
            Time raceTime = Time.valueOf(raceTimeField.getText());

            Race race = new Race(raceId, raceName, trackName, raceDate, raceTime);
            String horseId = horseIdField.getText();
            String result = resultField.getText();
            double prize;
            try {
                prize = Double.parseDouble(prizeField.getText());
            } catch (NumberFormatException e) {
                throw new InputMismatchException("Prize must be a valid number.");
            }

            RaceResults raceResult = new RaceResults(raceId, horseId, result, prize);
            List<RaceResults> results = new ArrayList<>();
            results.add(raceResult);

            adminService.addRace(race, results);

            showAlert(Alert.AlertType.INFORMATION, "Success", "Race added successfully!");
            clearFields();
        } catch (InputMismatchException e) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", e.getMessage());
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to add race: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/AdminView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Admin Menu");
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void clearFields() {
        raceIdField.clear();
        raceNameField.clear();
        trackNameField.clear();
        raceDateField.clear();
        raceTimeField.clear();
        horseIdField.clear();
        resultField.clear();
        prizeField.clear();
    }
}

