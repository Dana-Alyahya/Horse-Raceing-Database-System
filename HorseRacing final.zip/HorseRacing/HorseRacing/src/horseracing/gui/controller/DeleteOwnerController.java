package horseracing.gui.controller;

import horseracing.services.AdminService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class DeleteOwnerController {

    @FXML
    private TextField ownerIdField;

    private AdminService adminService = new AdminService();

    @FXML
    private void handleDeleteOwner(ActionEvent event) {
        if (ownerIdField.getText().trim().isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Validation Error", "Owner ID must be filled out.");
            return;
        }
        try {
            String ownerId = ownerIdField.getText();
            adminService.deleteOwner(ownerId);
            showAlert(Alert.AlertType.INFORMATION, "Success", "Owner deleted successfully!");
            ownerIdField.clear();
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to delete owner: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBackToAdmin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/AdminView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Admin Menu");
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

