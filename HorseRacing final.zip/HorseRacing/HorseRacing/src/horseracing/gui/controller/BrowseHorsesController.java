package horseracing.gui.controller;

import horseracing.services.GuestService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.List;

public class BrowseHorsesController {

    @FXML
    private TextField ownerLastNameField;
    @FXML
    private ListView<String> horseListView;

    private GuestService guestService = new GuestService();

    @FXML
    private void handleBrowseHorses(ActionEvent event) {
        try {
            String lastName = ownerLastNameField.getText();
            if (lastName.isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Input Error", "Please enter an owner last name.");
                return;
            }
            List<String> horses = guestService.browseHorsesByOwner(lastName);
            ObservableList<String> observableHorses = FXCollections.observableArrayList(horses);
            horseListView.setItems(observableHorses);

            if (horses.isEmpty()) {
                showAlert(Alert.AlertType.INFORMATION, "No Results", "No horses found for the given owner last name.");
            }
        } catch (Exception e) {
            showAlert(Alert.AlertType.ERROR, "Error", "Failed to browse horses: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleBackToGuest(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/GuestView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Guest Menu");
        stage.setScene(new Scene(root));
        stage.show();
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}

