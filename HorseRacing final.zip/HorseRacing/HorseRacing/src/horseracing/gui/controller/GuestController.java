package horseracing.gui.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class GuestController {

    @FXML
    private void handleBrowseHorses(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/BrowseHorsesView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Browse Horses by Owner Last Name");
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleListWinningTrainers(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/ListWinningTrainersView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Trainers with Winning Horses");
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleListTrainerWinnings(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/ListTrainerWinningsView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Trainers with Total Winnings");
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleListTracks(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/ListTracksView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Tracks with Race and Horse Counts");
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleBackToLogin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/LoginView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Horse Racing Database System");
        stage.setScene(new Scene(root));
        stage.show();
    }
}

