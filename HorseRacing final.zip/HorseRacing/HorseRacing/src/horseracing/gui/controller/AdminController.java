package horseracing.gui.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminController {

    @FXML
    private void handleAddRace(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/AddRaceView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Add New Race");
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleDeleteOwner(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/DeleteOwnerView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Delete Owner");
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleMoveHorse(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/MoveHorseView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Move Horse to Another Stable");
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleApproveTrainer(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/ApproveTrainerView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Approve Trainer to Join Stable");
        stage.setScene(new Scene(root));
        stage.show();
    }

    @FXML
    private void handleBackToLogin(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("../view/LoginView.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setTitle("Horse Racing Database System");
        stage.setScene(new Scene(root));
        stage.show();
    }
}

