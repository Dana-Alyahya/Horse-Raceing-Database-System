package horseracing.dao;

import horseracing.database.DBConnection;
import horseracing.model.Race;
import horseracing.model.RaceResults;

import java.sql.*;
import java.util.List;

public class RaceDAO {

    public void addRace(Race race, List<RaceResults> results) throws Exception {
        String raceSql = "INSERT INTO Race VALUES (?,?,?,?,?)";
        String resultSql = "INSERT INTO RaceResults VALUES (?,?,?,?)";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement raceStmt = conn.prepareStatement(raceSql)) {
                raceStmt.setString(1, race.getRaceId());
                raceStmt.setString(2, race.getRaceName());
                raceStmt.setString(3, race.getTrackName());
                raceStmt.setDate(4, race.getRaceDate());
                raceStmt.setTime(5, race.getRaceTime());
                raceStmt.executeUpdate();
            }

            try (PreparedStatement resultStmt = conn.prepareStatement(resultSql)) {
                for (RaceResults rr : results) {
                    resultStmt.setString(1, rr.getRaceId());
                    resultStmt.setString(2, rr.getHorseId());
                    resultStmt.setString(3, rr.getResults());
                    resultStmt.setDouble(4, rr.getPrize());
                    resultStmt.addBatch();
                }
                resultStmt.executeBatch();
            }

            conn.commit();
        }
    }
}

