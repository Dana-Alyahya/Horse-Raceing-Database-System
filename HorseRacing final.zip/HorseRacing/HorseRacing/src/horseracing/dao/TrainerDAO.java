package horseracing.dao;

import horseracing.database.DBConnection;

import java.sql.*;
import java.util.*;

public class TrainerDAO {

    // Admin: assign trainer to stable
    public void assignStable(String trainerId, String stableId) throws Exception {
        String sql = "UPDATE Trainer SET stableId = ? WHERE trainerId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, stableId);
            stmt.setString(2, trainerId);
            stmt.executeUpdate();
        }
    }

    // Guest: trainers who trained winners
    public List<String> getWinningTrainers() throws Exception {
        List<String> list = new ArrayList<>();
        String sql = "SELECT t.fname, t.lname, h.horseName, r.raceName " +
                "FROM Trainer t " +
                "JOIN Stable s ON t.stableId = s.stableId " +
                "JOIN Horse h ON h.stableId = s.stableId " +
                "JOIN RaceResults rr ON h.horseId = rr.horseId " +
                "JOIN Race r ON rr.raceId = r.raceId " +
                "WHERE rr.results = 'first'";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add("Trainer: " + rs.getString("fname") + " " + rs.getString("lname") +
                        ", Horse: " + rs.getString("horseName") +
                        ", Race: " + rs.getString("raceName"));
            }
        }
        return list;
    }

    // Guest: trainers and total winnings
    public List<String> getTrainerWinnings() throws Exception {
        List<String> list = new ArrayList<>();
        String sql = "SELECT t.fname, t.lname, SUM(rr.prize) AS total " +
                "FROM Trainer t " +
                "JOIN Stable s ON t.stableId = s.stableId " +
                "JOIN Horse h ON h.stableId = s.stableId " +
                "JOIN RaceResults rr ON h.horseId = rr.horseId " +
                "GROUP BY t.trainerId " +
                "ORDER BY total DESC";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add("Trainer: " + rs.getString("fname") + " " + rs.getString("lname") +
                        ", Total Winnings: " + rs.getDouble("total"));
            }
        }
        return list;
    }
}

