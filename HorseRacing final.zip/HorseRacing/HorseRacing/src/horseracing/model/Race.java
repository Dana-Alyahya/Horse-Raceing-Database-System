package horseracing.model;
// Race.java
import java.sql.Date;
import java.sql.Time;

public class Race {
    private String raceId;
    private String raceName;
    private String trackName;
    private Date raceDate;
    private Time raceTime;

    // Constructors, getters, setters


    public Race(String raceId, String raceName, String trackName, Date raceDate, Time raceTime) {
        this.raceId = raceId;
        this.raceName = raceName;
        this.trackName = trackName;
        this.raceDate = raceDate;
        this.raceTime = raceTime;
    }

    public String getRaceId() {
        return raceId;
    }

    public void setRaceId(String raceId) {
        this.raceId = raceId;
    }

    public String getRaceName() {
        return raceName;
    }

    public void setRaceName(String raceName) {
        this.raceName = raceName;
    }

    public String getTrackName() {
        return trackName;
    }

    public void setTrackName(String trackName) {
        this.trackName = trackName;
    }

    public Date getRaceDate() {
        return raceDate;
    }

    public void setRaceDate(Date raceDate) {
        this.raceDate = raceDate;
    }

    public Time getRaceTime() {
        return raceTime;
    }

    public void setRaceTime(Time raceTime) {
        this.raceTime = raceTime;
    }

    @Override
    public String toString() {
        return "Race{" +
                "raceId='" + raceId + '\'' +
                ", raceName='" + raceName + '\'' +
                ", trackName='" + trackName + '\'' +
                ", raceDate=" + raceDate +
                ", raceTime=" + raceTime +
                '}';
    }
}

