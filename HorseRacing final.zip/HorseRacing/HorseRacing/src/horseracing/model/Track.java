package horseracing.model;

// Track.java
public class Track {
    private String trackName;
    private String location;
    private int length;

    // Constructors, getters, setters

    public Track(String trackName, String location, int length) {
        this.trackName = trackName;
        this.location = location;
        this.length = length;
    }

    public String getTrackName() {
        return trackName;
    }

    public void setTrackName(String trackName) {
        this.trackName = trackName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    @Override
    public String toString() {
        return "Track{" +
                "trackName='" + trackName + '\'' +
                ", location='" + location + '\'' +
                ", length=" + length +
                '}';
    }
}

