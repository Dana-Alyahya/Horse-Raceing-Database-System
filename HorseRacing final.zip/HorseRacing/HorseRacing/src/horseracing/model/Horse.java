package horseracing.model;

// Horse.java
public class Horse {
    private String horseId;
    private String horseName;
    private int age;
    private char gender;
    private int registration;
    private String stableId;  // Foreign key

    // Constructors, getters, setters


    public Horse(String horseId, String horseName, int age, char gender, int registration, String stableId) {
        this.horseId = horseId;
        this.horseName = horseName;
        this.age = age;
        this.gender = gender;
        this.registration = registration;
        this.stableId = stableId;
    }

    public String getHorseId() {
        return horseId;
    }

    public void setHorseId(String horseId) {
        this.horseId = horseId;
    }

    public String getHorseName() {
        return horseName;
    }

    public void setHorseName(String horseName) {
        this.horseName = horseName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public char getGender() {
        return gender;
    }

    public void setGender(char gender) {
        this.gender = gender;
    }

    public int getRegistration() {
        return registration;
    }

    public void setRegistration(int registration) {
        this.registration = registration;
    }

    public String getStableId() {
        return stableId;
    }

    public void setStableId(String stableId) {
        this.stableId = stableId;
    }

    @Override
    public String toString() {
        return "Horse{" +
                "horseId='" + horseId + '\'' +
                ", horseName='" + horseName + '\'' +
                ", age=" + age +
                ", gender=" + gender +
                ", registration=" + registration +
                ", stableId='" + stableId + '\'' +
                '}';
    }
}
