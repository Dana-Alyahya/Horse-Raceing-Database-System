package horseracing.model;

// Trainer.java
public class Trainer {
    private String trainerId;
    private String lname;
    private String fname;
    private String stableId;

    // Constructors, getters, setters


    public Trainer(String trainerId, String lname, String fname, String stableId) {
        this.trainerId = trainerId;
        this.lname = lname;
        this.fname = fname;
        this.stableId = stableId;
    }

    public String getTrainerId() {
        return trainerId;
    }

    public void setTrainerId(String trainerId) {
        this.trainerId = trainerId;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getStableId() {
        return stableId;
    }

    public void setStableId(String stableId) {
        this.stableId = stableId;
    }

    @Override
    public String toString() {
        return "Trainer{" +
                "trainerId='" + trainerId + '\'' +
                ", lname='" + lname + '\'' +
                ", fname='" + fname + '\'' +
                ", stableId='" + stableId + '\'' +
                '}';
    }
}

