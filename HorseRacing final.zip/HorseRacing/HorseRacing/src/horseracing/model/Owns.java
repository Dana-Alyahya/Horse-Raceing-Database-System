package horseracing.model;

// Owns.java
public class Owns {
    private String ownerId;
    private String horseId;

    // Constructors, getters, setters

    public Owns(String ownerId, String horseId) {
        this.ownerId = ownerId;
        this.horseId = horseId;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public String getHorseId() {
        return horseId;
    }

    public void setHorseId(String horseId) {
        this.horseId = horseId;
    }

    @Override
    public String toString() {
        return "Owns{" +
                "ownerId='" + ownerId + '\'' +
                ", horseId='" + horseId + '\'' +
                '}';
    }
}

