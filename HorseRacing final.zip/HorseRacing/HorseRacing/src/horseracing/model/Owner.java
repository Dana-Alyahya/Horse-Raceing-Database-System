package horseracing.model;

// Owner.java
public class Owner {
    private String ownerId;
    private String lname;
    private String fname;

    // Constructors, getters, setters

    public Owner(String ownerId, String lname, String fname) {
        this.ownerId = ownerId;
        this.lname = lname;
        this.fname = fname;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    @Override
    public String toString() {
        return "Owner{" +
                "ownerId='" + ownerId + '\'' +
                ", lname='" + lname + '\'' +
                ", fname='" + fname + '\'' +
                '}';
    }
}

