import horseracing.gui.MainApp;

public class Main {
    public static void main(String[] args) {
        MainApp.main(args);
    }
}

//ok? We should be able to add the results of the race in admin you didnt add it I sent you on whats app