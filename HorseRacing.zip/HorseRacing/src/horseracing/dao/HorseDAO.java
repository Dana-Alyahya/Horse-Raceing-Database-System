package horseracing.dao;

// HorseDAO.java
import horseracing.model.DBConnection;
import horseracing.model.Horse;

import java.sql.*;
import java.util.*;

public class HorseDAO {

    public void addHorse(Horse horse) throws Exception {
        String sql = "INSERT INTO Horse VALUES (?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, horse.getHorseId());
            stmt.setString(2, horse.getHorseName());
            stmt.setInt(3, horse.getAge());
            stmt.setString(4, String.valueOf(horse.getGender()));
            stmt.setInt(5, horse.getRegistration());
            stmt.setString(6, horse.getStableId());
            stmt.executeUpdate();
        }
    }

    public List<Horse> getAllHorses() throws Exception {
        List<Horse> horses = new ArrayList<>();
        String sql = "SELECT * FROM Horse";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                horses.add(new Horse(
                        rs.getString("horseId"),
                        rs.getString("horseName"),
                        rs.getInt("age"),
                        rs.getString("gender").charAt(0),
                        rs.getInt("registration"),
                        rs.getString("stableId")
                ));
            }
        }
        return horses;
    }

    public void updateStable(String horseId, String newStableId) throws Exception {
        String sql = "UPDATE Horse SET stableId = ? WHERE horseId = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newStableId);
            stmt.setString(2, horseId);
            stmt.executeUpdate();
        }
    }

    // Guest: list horses by owner’s last name
    public List<String> getHorsesByOwner(String ownerLname) throws Exception {
        List<String> list = new ArrayList<>();
        String sql = "SELECT h.horseName, h.age, t.fname, t.lname " +
                "FROM Horse h " +
                "JOIN Owns o ON h.horseId = o.horseId " +
                "JOIN Owner ow ON ow.ownerId = o.ownerId " +
                "JOIN Stable s ON h.stableId = s.stableId " +
                "JOIN Trainer t ON s.stableId = t.stableId " +
                "WHERE ow.lname = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, ownerLname);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                list.add("Horse: " + rs.getString("horseName") +
                        ", Age: " + rs.getInt("age") +
                        ", Trainer: " + rs.getString("fname") + " " + rs.getString("lname"));
            }
        }
        return list;
    }
}
