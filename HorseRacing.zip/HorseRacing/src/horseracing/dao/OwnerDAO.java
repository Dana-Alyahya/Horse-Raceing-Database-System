package horseracing.dao;

import horseracing.model.DBConnection;

import java.sql.*;

public class OwnerDAO {

    // Call stored procedure: delete_owner(ownerId)
    public void deleteOwner(String ownerId) throws Exception {
        String sql = "{ call delete_owner(?) }";
        try (Connection conn = DBConnection.getConnection();
             CallableStatement stmt = conn.prepareCall(sql)) {
            stmt.setString(1, ownerId);
            stmt.execute();
        }
    }
}

