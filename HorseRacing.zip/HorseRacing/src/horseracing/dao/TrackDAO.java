package horseracing.dao;

import horseracing.model.DBConnection;

import java.sql.*;
import java.util.*;

public class TrackDAO {

    public List<String> getTrackStats() throws Exception {
        List<String> list = new ArrayList<>();
        String sql = "SELECT tr.trackName, COUNT(DISTINCT r.raceId) AS raceCount, COUNT(DISTINCT rr.horseId) AS horseCount " +
                "FROM Track tr " +
                "LEFT JOIN Race r ON tr.trackName = r.trackName " +
                "LEFT JOIN RaceResults rr ON r.raceId = rr.raceId " +
                "GROUP BY tr.trackName";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add("Track: " + rs.getString("trackName") +
                        ", Races: " + rs.getInt("raceCount") +
                        ", Horses: " + rs.getInt("horseCount"));
            }
        }
        return list;
    }
}

