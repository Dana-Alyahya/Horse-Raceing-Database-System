package horseracing.services;

import horseracing.dao.HorseDAO;
import horseracing.dao.OwnerDAO;
import horseracing.dao.RaceDAO;
import horseracing.dao.TrainerDAO;
import horseracing.model.Race;
import horseracing.model.RaceResults;

import java.util.List;

// AdminService.java
public class AdminService {
    private RaceDAO raceDAO = new RaceDAO();
    private OwnerDAO ownerDAO = new OwnerDAO();
    private HorseDAO horseDAO = new HorseDAO();
    private TrainerDAO trainerDAO = new TrainerDAO();

    public void addRace(Race race, List<RaceResults> results) throws Exception {
        raceDAO.addRace(race, results);
    }

    public void deleteOwner(String ownerId) throws Exception {
        ownerDAO.deleteOwner(ownerId); // calls stored procedure
    }

    public void moveHorse(String horseId, String newStableId) throws Exception {
        horseDAO.updateStable(horseId, newStableId);
    }

    public void approveTrainer(String trainerId, String stableId) throws Exception {
        trainerDAO.assignStable(trainerId, stableId);
    }
}

