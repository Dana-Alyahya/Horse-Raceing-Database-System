package horseracing.services;

import horseracing.dao.HorseDAO;
import horseracing.dao.TrackDAO;
import horseracing.dao.TrainerDAO;

// GuestService.java
public class GuestService {
    private HorseDAO horseDAO = new HorseDAO();
    private TrainerDAO trainerDAO = new TrainerDAO();
    private TrackDAO trackDAO = new TrackDAO();

    public void browseHorsesByOwner(String ownerLname) throws Exception {
        horseDAO.getHorsesByOwner(ownerLname).forEach(System.out::println);
    }

    public void listWinningTrainers() throws Exception {
        trainerDAO.getWinningTrainers().forEach(System.out::println);
    }

    public void listTrainerWinnings() throws Exception {
        trainerDAO.getTrainerWinnings().forEach(System.out::println);
    }

    public void listTracksWithRaceCounts() throws Exception {
        trackDAO.getTrackStats().forEach(System.out::println);
    }
}

