package horseracing.model;

// Stable.java
public class Stable {
    private String stableId;
    private String stableName;
    private String location;
    private String colors;

    // Constructors, getters, setters


    public Stable(String stableId, String stableName, String location, String colors) {
        this.stableId = stableId;
        this.stableName = stableName;
        this.location = location;
        this.colors = colors;
    }

    public String getStableId() {
        return stableId;
    }

    public void setStableId(String stableId) {
        this.stableId = stableId;
    }

    public String getStableName() {
        return stableName;
    }

    public void setStableName(String stableName) {
        this.stableName = stableName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getColors() {
        return colors;
    }

    public void setColors(String colors) {
        this.colors = colors;
    }

    @Override
    public String toString() {
        return "Stable{" +
                "stableId='" + stableId + '\'' +
                ", stableName='" + stableName + '\'' +
                ", location='" + location + '\'' +
                ", colors='" + colors + '\'' +
                '}';
    }
}

