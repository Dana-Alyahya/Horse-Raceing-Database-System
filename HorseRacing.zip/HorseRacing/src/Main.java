import horseracing.model.Race;
import horseracing.model.RaceResults;
import horseracing.services.AdminService;
import horseracing.services.GuestService;

import java.util.*;

public class Main {
    private static Scanner sc = new Scanner(System.in);
    private static AdminService adminService = new AdminService();
    private static GuestService guestService = new GuestService();

    public static void main(String[] args) {
        System.out.println("=== Horse Racing Database System ===");
        System.out.print("Login as (1) Admin or (2) Guest: ");
        int choice = sc.nextInt();
        sc.nextLine(); // consume newline

        try {
            if (choice == 1) {
                adminMenu();
            } else {
                guestMenu();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void adminMenu() throws Exception {
        while (true) {
            System.out.println("\n--- Admin Menu ---");
            System.out.println("1. Add new race");
            System.out.println("2. Delete owner");
            System.out.println("3. Move horse to another stable");
            System.out.println("4. Approve trainer to join a stable");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            int option = sc.nextInt();
            sc.nextLine();

            switch (option) {
                case 1:
                    addRaceOption();
                    break;
                case 2:
                    System.out.print("Enter owner ID to delete: ");
                    String ownerId = sc.nextLine();
                    adminService.deleteOwner(ownerId);
                    System.out.println("Owner deleted (via stored procedure).");
                    break;
                case 3:
                    System.out.print("Enter horse ID: ");
                    String horseId = sc.nextLine();
                    System.out.print("Enter new stable ID: ");
                    String stableId = sc.nextLine();
                    adminService.moveHorse(horseId, stableId);
                    System.out.println("Horse moved.");
                    break;
                case 4:
                    System.out.print("Enter trainer ID: ");
                    String trainerId = sc.nextLine();
                    System.out.print("Enter stable ID: ");
                    String stId = sc.nextLine();
                    adminService.approveTrainer(trainerId, stId);
                    System.out.println("Trainer approved.");
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void addRaceOption() throws Exception {
        System.out.print("Enter race ID: ");
        String raceId = sc.nextLine();
        System.out.print("Enter race name: ");
        String raceName = sc.nextLine();
        System.out.print("Enter track name: ");
        String trackName = sc.nextLine();
        System.out.print("Enter race date (YYYY-MM-DD): ");
        String date = sc.nextLine();
        System.out.print("Enter race time (HH:MM:SS): ");
        String time = sc.nextLine();

        Race race = new Race(raceId, raceName, trackName,
                java.sql.Date.valueOf(date), java.sql.Time.valueOf(time));

        List<RaceResults> results = new ArrayList<>();
        while (true) {
            System.out.print("Add race result? (y/n): ");
            if (!sc.nextLine().equalsIgnoreCase("y")) break;

            System.out.print("Horse ID: ");
            String horseId = sc.nextLine();
            System.out.print("Result (e.g., first, second): ");
            String res = sc.nextLine();
            System.out.print("Prize: ");
            double prize = sc.nextDouble();
            sc.nextLine();

            results.add(new RaceResults(raceId, horseId, res, prize));
        }

        adminService.addRace(race, results);
        System.out.println("Race and results added.");
    }

    private static void guestMenu() throws Exception {
        while (true) {
            System.out.println("\n--- Guest Menu ---");
            System.out.println("1. Browse horses by owner last name");
            System.out.println("2. List trainers with winning horses");
            System.out.println("3. List trainers with total winnings");
            System.out.println("4. List tracks with race and horse counts");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");
            int option = sc.nextInt();
            sc.nextLine();

            switch (option) {
                case 1:
                    System.out.print("Enter owner last name: ");
                    String lname = sc.nextLine();
                    guestService.browseHorsesByOwner(lname);
                    break;
                case 2:
                    guestService.listWinningTrainers();
                    break;
                case 3:
                    guestService.listTrainerWinnings();
                    break;
                case 4:
                    guestService.listTracksWithRaceCounts();
                    break;
                case 0:
                    return;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
